#include "samples.h"

SAMPLES::SAMPLES()
{

}
